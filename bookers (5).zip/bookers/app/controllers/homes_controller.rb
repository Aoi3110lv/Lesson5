class HomesController < ApplicationController
  def top
    # TODO: 後でもっかい考える
  end
end
